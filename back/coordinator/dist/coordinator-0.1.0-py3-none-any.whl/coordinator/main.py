import logging

import cqrs
from core.application.factories import ServiceAdapterFactory, create_mediator
from core.application.ports import Service, ServiceDiscoveryPort
from core.application.ports.coordinator import CoordinatorPort
from core.application.ports.realtime_storage import RealTimeStoragePort
from core.application.use_cases.report_emergency import (
    ReportEmergencyCommand,
    ReportEmergencyHandler,
)
from core.domain.entities import Emergency
from cqrs.container.dependency_injector import DependencyInjectorCQRSContainer
from cqrs.container.protocol import Container as CQRSContainer
from cqrs.requests import bootstrap
from dependency_injector import containers, providers
from docker_discovery import DockerServiceDiscoveryAdapter
from fastapi.applications import FastAPI

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)

logger = logging.getLogger(__name__)

app = FastAPI()


class RestCoordinatorAdapter(CoordinatorPort):
    requiredServices = ["fitsme"]

    async def report_emergency(self, emergency: Emergency):
        logger.info(self._serviceDirectory)
        logger.info("Emergency reported")


class NothingHappensRealTimeStorageAdapter(RealTimeStoragePort):
    async def save_emergency(self, emergency: Emergency):
        logger.info(
            f"The emergency has been saved on realtime db: {emergency.location}"
        )


# class ServiceDiscoveryAdapter(ServiceDiscoveryPort):
#     def get_service(self, service_name: str) -> Service:
#         return Service(host=service_name, port=0)


discoveryAdapter = DockerServiceDiscoveryAdapter()
coordinatorAdapter = RestCoordinatorAdapter()
appMediator: cqrs.RequestMediator = create_mediator(
    discoveryAdapter,
    ports=[RealTimeStoragePort],
    useCases=[(ReportEmergencyCommand, ReportEmergencyHandler)],
    adapter=coordinatorAdapter,
)

#
#
# class ApplicationContainer(containers.DeclarativeContainer):
#     coordinator = providers.Singleton(RestCoordinatorAdapter)
#     realtimeStorage = providers.Singleton(NothingHappensRealTimeStorageAdapter)
#     reportEmergencyHandler = providers.Factory(
#         ReportEmergencyHandler, storage=realtimeStorage, coordinator=coordinator
#     )
#
#
# def setup_di_container() -> CQRSContainer:
#     container = ApplicationContainer()
#     cqrs_container = DependencyInjectorCQRSContainer()
#     cqrs_container.attach_external_container(container)
#     return cqrs_container
#
#
# def commands_mapper(mapper: cqrs.RequestMap) -> None:
#     mapper.bind(ReportEmergencyCommand, ReportEmergencyHandler)
#
#
# mediator = bootstrap.bootstrap(
#     di_container=setup_di_container(), commands_mapper=commands_mapper
# )


@app.get("/")
def hello():
    return {"hello": "world"}


@app.post("/emergency")
async def report_emergency(emergencyCommand: ReportEmergencyCommand):
    await appMediator.send(emergencyCommand)
